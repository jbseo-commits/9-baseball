9-baseball existing game + night stadium + additive Red Fox
Extract all files preserving dist/assets. Run: python3 -m http.server 8000 --directory dist
Open http://localhost:8000/?battleUi=vnext&battlePlay=1&seed=20261119 in a fresh browser session.
On Android use a trusted local HTTP server app or same-network computer server. This ZIP is not an APK. No public deployment.
Vite base=./; static HTTP required (not file://). Entire dist retained; no CDN/runtime server dependency. Existing main route/controller/rules. Original pitchers retained. Review seed places Red Fox first.
6 held poses, high/back release and nonuniform background mapping remain HELD. Not final quality approval.
