9-baseball #140 follow-up: earned public outside confirmation badge.
Extract. python3 -m http.server 8000 --directory dist
Open http://localhost:8000/?battleUi=vnext&battlePlay=1&seed=20261119
base=./. Full dist retained; HTTP required. No new mode/rules/timing. No deployment.
