Existing 9-baseball real game: pixel batter + camera-aligned stadium + public intent badge.
Extract all files. python3 -m http.server 8000 --directory dist
Open http://localhost:8000/?battleUi=vnext&battlePlay=1&seed=20261119 in a fresh browser session.
Vite base=./; HTTP required, not file://. Full dist retained. No deployment.
Six authored source poses held across existing14slots. Existing game timing/rules unchanged. Source art remains review quality.
